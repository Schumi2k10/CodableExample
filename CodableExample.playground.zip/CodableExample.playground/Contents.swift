//: Playground - noun: a place where people can play


import UIKit

//: example Structs to Demostrate Codable

struct Adress: Codable {
    var street: String?
    var number: String?
    var city: String?
    var zip: String?
}

struct User: Codable {
    var firstName: String?
    var lastName: String?
    var email: String?
    var adress: Adress?
}

let user = User(firstName: "Patrick",
                lastName: "Schumacher",
                email: "schumacher.patrick@googlemail.com",
                adress: Adress(street: "bla",
                               number: "13",
                               city: "Essen",
                               zip: "45359"))

//: For JSON

let jsonEncoder = JSONEncoder()
jsonEncoder.outputFormatting = .prettyPrinted
let data: Data?
do  {
    data = try jsonEncoder.encode(user)
} catch {
    data = nil
    print("Something goes wrong")
}
if let data = data {
    let dataString = String(data: data, encoding: .utf8)
    print(dataString!)
}

var jsonString = """
{
"firstName" : "Patrick",
"email" : "schumacher.patrick@googlemail.com",
"lastName" : "Schumacher",
"adress" : {
"number" : "13",
"street" : "bla",
"city" : "Essen",
"zip" : "45359"
}
}
"""

let jsonDecode = JSONDecoder()
if let json = jsonString.data(using: .utf8) {
    do {
        let user1 = try jsonDecode.decode(User.self, from: json)
        print(user1.adress?.city)
    } catch {
        print("Something goes wrong")
    }
}

//: For NSKeyedArchvier

let archiver = NSKeyedArchiver()

let archiveData: Data?
do {
    try archiver.encodeEncodable(user, forKey: "user")
    archiveData = archiver.encodedData
} catch {
    archiveData = nil
    print("Something goes wrong")
}

if let decodedData = archiveData {
    let unarchiver = NSKeyedUnarchiver(forReadingWith: decodedData)
    let archiveUser = unarchiver.decodeDecodable(User.self, forKey: "user")
    print(archiveUser?.lastName)
}


